<?php include("../path.php"); ?>
<?php include(ROOT_PATH . "/app/controllers/posts.php");
	adminOnly();

    $admin_query_result = mysqli_query($conn, "SELECT COUNT(*) as totaladmin FROM users WHERE admin = 1");
	$totaladmin_data = mysqli_fetch_assoc($admin_query_result);
	$totalAdmins = $totaladmin_data['totaladmin'];

    $users_query_result = mysqli_query($conn, "SELECT COUNT(*) as totalusers FROM users WHERE admin = 0");
	$totalusers_data = mysqli_fetch_assoc($users_query_result);
	$totalUsers = $totalusers_data['totalusers'];

    $P_posts_query_result = mysqli_query($conn, "SELECT COUNT(*) as totalpposts FROM posts WHERE published = 1");
	$totalpposts_data = mysqli_fetch_assoc($P_posts_query_result);
	$totalPPosts = $totalpposts_data['totalpposts'];

    $UP_posts_query_result = mysqli_query($conn, "SELECT COUNT(*) as totalupposts FROM posts WHERE published = 0");
	$totalupposts_data = mysqli_fetch_assoc($UP_posts_query_result);
	$totalUPPosts = $totalupposts_data['totalupposts'];

    $topics_query_result = mysqli_query($conn, "SELECT COUNT(*) as totaltopics FROM topics");
	$totaltopics_data = mysqli_fetch_assoc($topics_query_result);
	$totalTopics = $totaltopics_data['totaltopics'];
    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
          integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr"
          crossorigin="anonymous">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Candal|Lora"
          rel="stylesheet">

    <!-- Custom Styling -->
    <link rel="stylesheet" href="../assets/css/style.css">

    <!-- Admin Styling -->
    <link rel="stylesheet" href="../assets/css/admin.css">

    <title>Admin Section - Dashboard</title>
</head>

<body>

<?php include(ROOT_PATH . "/app/includes/header.php"); ?>

<!-- Admin Page Wrapper -->
<div class="admin-wrapper">
	
	<?php include(ROOT_PATH . "/app/includes/adminSidebar.php"); ?>


    <!-- Admin Content -->
    <div class="admin-content">

        <div class="content">

            <h2 class="page-title">Cognitive HUB Dashboard</h2>
			
			<?php include(ROOT_PATH . '/app/includes/messages.php'); ?>

            <table style = "border: 1px solid white;  border-collapse: collapse; background-color: #cceaea; text-align: center;">
                <tr>
                    <th>Admins</th>
                    <th>Users</th>
                    <th>Published Posts</th>
                    <th>Unpublished Posts</th>
                    <th>Topics</th>
                </tr>

                <tr>
                    <td><?php echo $totalAdmins ?></td>
                    <td><?php echo $totalUsers ?></td>
                    <td><?php echo $totalPPosts ?></td>
                    <td><?php echo $totalUPPosts ?></td>
                    <td><?php echo $totalTopics ?></td>
                </tr>
            </table>

        </div>

    </div>
    <!-- // Admin Content -->

</div>
<!-- // Page Wrapper -->


<!-- JQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<!-- Ckeditor -->
<script src="https://cdn.ckeditor.com/ckeditor5/12.2.0/classic/ckeditor.js"></script>

<!-- Custom Script -->
<script src="../assets/js/scripts.js"></script>

</body>

</html>