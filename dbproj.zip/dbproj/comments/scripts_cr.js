$(document).ready(function(){
	load_comment();

	function load_comment(){
		var post_url;
		post_url = window. location. search;
		var params = new URLSearchParams(post_url);
		var pid = params.get('id');

		$.ajax({
			type: "POST",
			dataType: "json",
			url: "functions.php",
			data: {
				"current_post": pid,
				"comment_load_data": true
			},
			success: function (response) {

				console.log(response);
				$.each(response, function (key, value){
					$('.comment-wrapper').
					append('<div class="comment-details" style="width: 91.5%; float: left;">' +
							'<span class="comment-name" style="font-weight: bold;"> '+ value.username +' </span>' +
							'<span class="comment-date" style="font-style: italic; font-size: 0.8em;"> '+ value.cmt['created_at'] +' </span>' +
							'<p style="margin-bottom: 0px;">'+ value.cmt['body'] +'</p>' +
							'<a class="reply-btn" data-id="'+ value.cmt['id'] +'" style="font-size: 0.8em;">Reply</a>' +
							'<a class="view-btn" data-id="'+ value.cmt['id'] +'" style="font-size: 0.8em;">View Replies</a>' +
							'<div class="reply_form">' +
							'</div>' +
						'</div>');
				});
			}
		});
	}

	$('#submit_comment').click(function (e){
		e.preventDefault();

		var post_url;
		post_url = new URL(this.href);
		var pid = post_url.searchParams.get("id");
		var comment_text = $('#comment_text').val();

		if($.trim(comment_text).length == 0){
			error_msg = "There was an error adding comment. Please try again";
		}else{
			error_msg = "";
		}

		if(error_msg != "") {
			return false;

		} else
		{
			var data = {
				'body': comment_text,
				'post_id' : pid,
				'add_comment': true,
			};
			$.ajax({
				type: "POST",
				url: "functions.php",
				data: data,
				success: function (response){
					alert(response);
					$('#comment_text').val("");
				}
			});
		}

	});

	$(document).on('click', '.reply-btn', function(e) {
		e.preventDefault();

		var thisClicked = $(this);
		var comment_id = thisClicked.val();

		$('.reply_form').html("");
		thisClicked.closest('.comment-details').find('.reply_form').
		html('<input type="text" class="reply_text form-control my-2" placeholder="Reply">\
				<div class="text-end">\
					<button class="btn btn-sm btn-primary submit-reply">Reply</button>\
					<button class="btn btn-sm btn-danger reply_cancel_btn">Cancel</button>\
				</div>');
	});

	$(document).on('click', '.reply_cancel_btn',function (e){
		$('.reply_form').html("");
	});

	$(document).on('click', '.submit-reply', function(e){
		e.preventDefault();

		var thisClicked = S(this);
		var comment_id = thisClicked.closest('.comment-details').find('.reply-btn').val();
		var reply = thisClicked.closest('.comment-details').find('.reply_text').val();
	/*	var reply_textarea = $(this).siblings('textarea'); // reply textarea element
		var reply_text = $(this).siblings('textarea').val();
		var url = $(this).parent().attr('action');*/

		var data = {
			'comment_id' : comment_id,
			'reply_text' : reply,
			'add_reply': true
		};

		$.ajax({
			type: "POST",
			url: "functions.php",
			data: data,
			success: function(response){
				alert(response);
				$('.reply_form').html("");
			}
		});
	});

/*		// show/hide the appropriate reply form (from the reply-btn (this), go to the parent element (comment-details)
		// and then its siblings which is a form element with id comment_reply_form_ + comment_id)
		$(this).parent().siblings('form#comment_reply_form_' + comment_id).toggle(500);
		$(document).on('click', '.submit-reply', function(e){
			e.preventDefault();
			// elements
			var reply_textarea = $(this).siblings('textarea'); // reply textarea element
			var reply_text = $(this).siblings('textarea').val();
			var url = $(this).parent().attr('action');

			$.ajax({
				url: url,
				type: "POST",
				data: {
					comment_id: comment_id,
					reply_text: reply_text,
					reply_posted: 1
				},
				success: function(data){
					if (data === "error") {
						alert('There was an error adding reply. Please try again');
					} else {
						$('.replies_wrapper_' + comment_id).append(data);
						reply_textarea.val("");
					}
				}
			});
		});
	});*/

	$(document).on('click', '.view-btn', function (e){
		e.preventDefault();

		var thisClicked = $(this);
		var cmt_id = thisClicked.val();

		$.ajax({
			type: "POST",
			url: "functions.php",
			data: {
				'cmt_id': cmt_id,
				'view_comment_data': true
			},
			success: function (response){
				$('.reply_form').html("");
				$.each(response, function (key, value){
					thisClicked.closest('.comment-details').find('.reply_form').
					append('<div class="sub_comment-details" style="width: 91.5%; float: left;">' +
						'<input type="hidden" class="get_username" value="'+ value.username +'">'+
						'<span class="comment-name" style="font-weight: bold;"> '+ value.username +' </span>' +
						'<span class="comment-date" style="font-style: italic; font-size: 0.8em;"> '+ value.cmt['created_at'] +' </span>' +
						'<p style="margin-bottom: 0px;">'+ value.cmt['body'] +'</p>' +
						'<a class="sub-reply-btn" data-id="'+ value.cmt['id'] +'" style="font-size: 0.8em;">Reply</a>' +
						'<div class="sub_reply_form">' +
						'</div>' +
						'</div>');
				});
			}
		});

	});

	$(document).on('click','.sub-reply-btn',function (e){
		e.preventDefault();

		var thisClicked = $(this);
		var cmt_id = thisClicked.val();
		var username = thisClicked.closest('.sub-reply-btn').find('.get_username').val();

		$('.sub_reply_form').html("");
		thisClicked.closest('.sub-reply-btn').find('.sub_reply_form').
		append('<input type="text" value="@'+username+'" class="sub_reply_text form-control my-2" placeholder="Reply">\
				<div class="text-end">\
					<button class="btn btn-sm btn-primary sub_submit_reply">Reply</button>\
					<button class="btn btn-sm btn-danger sub_reply_cancel_btn">Cancel</button>\
				</div>');
	});


	$(document).on('click','.sub_submit_btn',function (e) {
		e.preventDefault();

		var thisClicked = $(this);
		var cmt_id = thisClicked.closest('.sub_reply_form').find('.sub-reply-btn').val();
		var reply = thisClicked.closest('.sub_reply_form').find('.sub_reply_text').val();

		var data = {
			'cmt_id': cmt_id,
			'reply_msg':reply,
			'add_subreplies': true
		}
		$.ajax({
			type: "POST",
			url: "functions.php",
			data: data,
			success: function(response){
				alert(response);
				$('.reply_form').html("");
			}
		});
	});


	$(document).on('click','.sub_reply_cancel_btn',function (e) {
		e.preventDefault();
		$('.sub_reply_form').html("");
	});

	// When user clicks on submit reply to add reply under comment

});