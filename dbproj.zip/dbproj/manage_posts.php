<?php include("path.php"); ?>
<?php include(ROOT_PATH . "/app/controllers/posts.php");
global $conn;
global $UID;
$UID = $_SESSION['id'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">

	<!-- Font Awesome -->
	<link rel="stylesheet"
	      href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
	      integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr"
	      crossorigin="anonymous">

	<!-- Google Fonts -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Candal|Lora">

	<!-- Custom Styling -->
	<link rel="stylesheet" href="assets/css/style.css">

	<!-- Admin Styling -->
	<link rel="stylesheet" href="assets/css/admin.css">

	<title>View Posts</title>
</head>

<body>

<?php include(ROOT_PATH . "/app/includes/header.php"); ?>

<!-- Admin Page Wrapper -->
<div class="admin-wrapper">
	<!-- Admin Content -->
	<div class="admin-content">

		<div class="content">
			<h2 class="page-title">YOUR POSTS</h2>
			<?php include(ROOT_PATH . "/app/includes/messages.php");
			$user_unpub_sql = "SELECT * FROM posts WHERE user_id = $UID ORDER BY created_at DESC";
			$user_unpub_dets = mysqli_query($conn , $user_unpub_sql);
			$usersql = "SELECT * FROM posts WHERE user_id = $UID AND published = 1 ORDER BY created_at DESC";
			$userp_dets = mysqli_query($conn , $usersql);
			$key = 0;
			if(mysqli_num_rows($userp_dets)>0){?>

			<table>
				<thead>
				<th>SN</th>
				<th>Title</th>
				<th>Topic</th>
				<th colspan="3">Action</th>
				</thead>
				<tbody>
			<?php
			
			while($post = mysqli_fetch_assoc($userp_dets)){?>
				<tr>
					<td><?php echo $key + 1; ?></td>
					<td><?php echo $post['title']; ?></td>
					<?php
						$currenttopic = $post['topic_id'];
						$sql = "SELECT * FROM topics WHERE id= '$currenttopic'";
						$topicdet = mysqli_query($conn, $sql);
						$topic = mysqli_fetch_array($topicdet); ?>

					<td><?php echo $topic['name']; ?></td>
					<td><a href="single.php?id=<?php echo $post['id']; ?> class="edit">view</a></td>
					<td><a href="admin/posts/edit.php?id=<?php echo $post['id']; ?>" class="edit">edit</a></td>
					<td><a href="admin/posts/edit.php?delete_id=<?php echo $post['id']; ?>" class="delete">delete</a></td>
				</tr>
				
				<?php ++$key;}}
					elseif(mysqli_num_rows($userp_dets)==0){
						if(mysqli_num_rows($user_unpub_dets)>0){?>
						<h4 style="text-align:center; color:#2980B9;">Your posts are not approved by admin yet</h4>
					<?php }elseif(mysqli_num_rows($user_unpub_dets) == 0){?>
						<h4 style="text-align:center; color:#2980B9;">You have not created any posts yet</h4>
					<?php }} ?>
				</tbody>
		</table>

		</div>

	</div>
	<!-- // Admin Content -->

</div>
<!-- // Page Wrapper -->


<!-- JQuery -->
<script
		src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Ckeditor -->
<script
		src="https://cdn.ckeditor.com/ckeditor5/12.2.0/classic/ckeditor.js"></script>
<!-- Custom Script -->
<script src="/assets/js/scripts.js"></script>

</body>

</html>