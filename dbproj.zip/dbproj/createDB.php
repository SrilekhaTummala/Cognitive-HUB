<!DOCTYPE html>
<html>
<body>

<h2>DB Creation </h2>
<form method="post">

    <div>
        <input type="submit" name="createDB" class="button" value="Create DB" style="font-size: 20px;"/>
    </div>
    <br>
    <br>
</form>

<form method="post">
    <h2> Table Creation</h2>
    <div>
        <input type="submit" name="createTables" class="button" value="Create Tables" style="font-size: 20px;"/>
    </div>
    <br>
    <br>
</form>

<form method="post">
    <h2>DB Deletion</h2>
    <div>
        <input type="submit" name="dropDB" class="button" value="Drop DB" style="font-size: 20px;"/>
    </div>

    <br>
    <br>
    <br>
    <br>


</form>


<?php
	if (array_key_exists('createDB', $_POST)) {
		createDB();
	} else if (array_key_exists('createTables', $_POST)) {
		createTables();
	} else if (array_key_exists('dropDB', $_POST)) {
		dropDB();
	}
	
	
	//Creating a connection
	function createDB() {
		$con = mysqli_connect("localhost", "root", "");
		$success = mysqli_query($con, "CREATE DATABASE IF NOT EXISTS dbproj");
		
		
		echo "Database created successfully\n";
		
		//Closing the connection
		mysqli_close($con);
	}
	
	function createTables() {
		$con = mysqli_connect("localhost", "root", "", "dbproj");
		mysqli_query($con, "CREATE TABLE IF NOT EXISTS discussion(
                                id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                parent_comment VARCHAR(500) NOT NULL,
                                users VARCHAR(1000) NOT NULL,
                                post VARCHAR(1000)   NOT NULL,
                                reg_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
		
		mysqli_query($con, "CREATE TABLE IF NOT EXISTS posts(
                              id int(11) NOT NULL,
                              user_id int(11) NOT NULL,
                              topic_id int(11) DEFAULT NULL,
                              title varchar(255) NOT NULL,
                              image varchar(255) NOT NULL,
                              body text NOT NULL,
                              r_link varchar(255) NOT NULL,
                              published tinyint(4) NOT NULL,
                              created_at timestamp NOT NULL DEFAULT current_timestamp)");
		
		mysqli_query($con, "CREATE TABLE IF NOT EXISTS topics(
                                id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                name varchar(255) not null,
                                description TEXT not null)");
		
		mysqli_query($con, "CREATE TABLE IF NOT EXISTS users(
                                id INT(11) not null UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                admin tinyint(4) NOT NULL,
                                username varchar(255) NOT NULL,
                                email varchar(255) NOT NULL,
                                password varchar(255) NOT NULL,
                                created_at timestamp NOT NULL DEFAULT current_timestamp)");
		
		//Closing the connection
		mysqli_close($con);
	}
	
	//Creating a connection
	function dropDB() {
		//Creating a connection
		$con = mysqli_connect("localhost", "root", "");
		
		if (!$con) {
			die('Could not connect: ' . mysqli_error());
		}
		
		$sql = 'DROP DATABASE dbproj';
		$retval = mysqli_query($con, $sql);
		
		if (!$retval) {
			die('Could not delete database db_test: ' . mysqli_error());
		}
		
		echo "Database deleted successfully\n";
		
		mysqli_close($con);
	}

?>


</body>
</html>