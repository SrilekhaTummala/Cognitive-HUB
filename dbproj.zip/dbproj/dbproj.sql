-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2022 at 03:06 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbproj`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `body` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `user_id`, `post_id`, `body`, `created_at`, `updated_at`) VALUES
(51, 102, 15, 'How to calculate the conduction of the system?', '2022-03-13 02:25:24', NULL),
(53, 110, 23, '\nIs it possible to levitate a superconductor just above another levitating superconductor?', '2022-03-13 14:27:04', NULL),
(55, 110, 23, 'Under what conditions does an ordinary conductor behave like a superconductor?', '2022-03-13 14:31:03', NULL),
(56, 118, 17, 'Does radiation any medium for heat transfer?', '2022-03-14 21:11:49', NULL),
(57, 113, 1, 'Are there any similar articles for other classification algorithms specially target towards textual features and mix of textual/numeric features?', '2022-03-14 21:14:24', NULL),
(58, 105, 16, 'Is the process of cooling air in air-conditioners employs convection?', '2022-03-14 21:21:03', NULL),
(59, 102, 32, 'Nice Post stummala1', '2022-03-14 21:57:18', NULL),
(60, 102, 34, 'Nice post @vkudaravalli', '2022-03-14 23:41:06', NULL),
(61, 102, 36, 'Nice post!', '2022-03-15 10:33:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `discussion`
--

CREATE TABLE `discussion` (
  `id` int(11) NOT NULL,
  `user` varchar(1000) NOT NULL,
  `r_id` int(11) DEFAULT NULL,
  `post` varchar(1000) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discussion`
--

INSERT INTO `discussion` (`id`, `user`, `r_id`, `post`, `date`) VALUES
(43, 'vakula', 32, 'Hello, I want some posts under the topic Power transmission lines. But, I cannot find any topics related to it. Can you add the topic?', '2022-03-15 10:36:09'),
(41, 'fahmad', 31, 'Hi there?', '2022-03-14 23:12:02'),
(38, 'vakula', 30, 'hello', '2022-03-13 14:35:49');

-- --------------------------------------------------------

--
-- Table structure for table `disc_reply`
--

CREATE TABLE `disc_reply` (
  `id` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `user` varchar(1000) NOT NULL,
  `body` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `disc_reply`
--

INSERT INTO `disc_reply` (`id`, `cid`, `user`, `body`, `created_at`) VALUES
(30, 38, 'stummala', 'Hello happy blogging!', '2022-03-14 22:43:47'),
(31, 41, 'stummala', 'Yes please', '2022-03-14 23:12:28'),
(32, 43, 'mhossain', 'Of course, we will list the topic. Please add your posts. Thank you for your interest', '2022-03-15 10:37:21');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `postid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `userid`, `postid`) VALUES
(118, 105, 1),
(130, 110, 1),
(104, 112, 1),
(93, 113, 1),
(80, 118, 1),
(119, 105, 4),
(131, 110, 4),
(105, 112, 4),
(94, 113, 4),
(81, 118, 4),
(79, 102, 15),
(123, 105, 15),
(77, 110, 15),
(110, 112, 15),
(98, 113, 15),
(86, 118, 15),
(124, 105, 16),
(133, 110, 16),
(111, 112, 16),
(99, 113, 16),
(88, 118, 16),
(125, 105, 17),
(137, 110, 17),
(112, 112, 17),
(100, 113, 17),
(89, 118, 17),
(74, 110, 18),
(122, 105, 19),
(138, 110, 19),
(108, 112, 19),
(97, 113, 19),
(85, 118, 19),
(129, 105, 20),
(140, 110, 20),
(113, 112, 20),
(101, 113, 20),
(90, 118, 20),
(128, 105, 21),
(141, 110, 21),
(114, 112, 21),
(102, 113, 21),
(91, 118, 21),
(127, 105, 22),
(142, 110, 22),
(115, 112, 22),
(103, 113, 22),
(92, 118, 22),
(150, 102, 23),
(126, 105, 23),
(159, 106, 23),
(151, 107, 23),
(78, 110, 23),
(155, 111, 23),
(117, 112, 23),
(157, 115, 23),
(158, 116, 23),
(160, 117, 23),
(121, 105, 24),
(107, 112, 24),
(96, 113, 24),
(84, 118, 24),
(148, 102, 27),
(120, 105, 28),
(144, 110, 28),
(106, 112, 28),
(95, 113, 28),
(82, 118, 28),
(145, 102, 32),
(146, 102, 33),
(147, 102, 34),
(149, 102, 36);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `published` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `image`, `body`, `published`, `created_at`) VALUES
(1, 102, 9, 'Naive Bayes', '1644248437_NaiveBayes_Classification.png', '&lt;p&gt;&lt;strong&gt;Definition: &lt;/strong&gt;Naive Bayes algorithm based on Bayes&rsquo; theorem with the assumption of independence between every pair of features. Naive Bayes classifiers work well in many real-world situations such as document classification and spam filtering.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Advantages: &lt;/strong&gt;This algorithm requires a small amount of training data to estimate the necessary parameters. Naive Bayes classifiers are extremely fast compared to more sophisticated methods.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Disadvantages: &lt;/strong&gt;Naive Bayes is is known to be a bad estimator.&lt;/p&gt;', 1, '2022-02-07 15:40:37'),
(2, 102, 9, 'k-Nearest Neighbours', '1644248603_knn_Classifiation.jpg', '&lt;p&gt;&lt;strong&gt;Definition: &lt;/strong&gt;Neighbours based classification is a type of lazy learning as it does not attempt to construct a general internal model, but simply stores instances of the training data. Classification is computed from a simple majority vote of the k nearest neighbours of each point.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Advantages: &lt;/strong&gt;This algorithm is simple to implement, robust to noisy training data, and effective if training data is large.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Disadvantages: &lt;/strong&gt;Need to determine the value of K and the computation cost is high as it needs to compute the distance of each instance to all the training samples.&lt;/p&gt;', 0, '2022-02-07 15:43:23'),
(4, 115, 10, 'Linear Regression', '1647138123_linear.PNG', '&lt;p&gt;We can evaluate&amp;nbsp;the model performance using the metric&amp;nbsp;&lt;strong&gt;R-square&lt;/strong&gt;. To know more details about these metrics, you can read:&amp;nbsp;Model Performance metrics &lt;a href=&quot;https://www.analyticsvidhya.com/blog/2015/01/model-performance-metrics-classification/&quot;&gt;Part 1&lt;/a&gt;, &lt;a href=&quot;https://www.analyticsvidhya.com/blog/2015/01/model-perform-part-2/&quot;&gt;Part 2&lt;/a&gt;&amp;nbsp;.&lt;/p&gt;&lt;p&gt;Important Points:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;There must be &lt;strong&gt;linear relationship&lt;/strong&gt; between independent and dependent variables&lt;/li&gt;&lt;li&gt;Multiple regression suffers from &lt;strong&gt;multicollinearity, autocorrelation, heteroskedasticity&lt;/strong&gt;.&lt;/li&gt;&lt;li&gt;Linear Regression is very sensitive to &lt;strong&gt;Outliers&lt;/strong&gt;. It can terribly affect the regression line and&amp;nbsp;eventually the forecasted values.&lt;/li&gt;&lt;li&gt;Multicollinearity can increase the variance of the coefficient estimates and make the estimates very sensitive to minor changes in the model. The result is that the coefficient estimates are unstable&lt;/li&gt;&lt;li&gt;In case of multiple independent variables, we can go with &lt;strong&gt;forward selection&lt;/strong&gt;, &lt;strong&gt;backward elimination&lt;/strong&gt; and &lt;strong&gt;step wise approach&lt;/strong&gt; for selection of most significant independent variables.It is one of the most widely known modeling technique. Linear regression is usually among the first few topics which people pick while learning predictive modeling.&amp;nbsp;In this technique,&amp;nbsp;the dependent variable is continuous, independent variable(s) can be &lt;a href=&quot;https://en.wikipedia.org/wiki/Continuous_and_discrete_variables&quot;&gt;continuous or discrete&lt;/a&gt;,&amp;nbsp;and nature of regression line is linear.&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;Linear Regression&amp;nbsp;establishes a&amp;nbsp;relationship between &lt;strong&gt;dependent variable (Y)&lt;/strong&gt; and one or more &lt;strong&gt;independent&amp;nbsp;variables (X)&lt;/strong&gt; using a &lt;strong&gt;best fit straight line&lt;/strong&gt; (also known as regression line).&lt;/p&gt;&lt;p&gt;It is&amp;nbsp;represented by an equation &lt;strong&gt;Y=a+b*X + e&lt;/strong&gt;, where a is intercept, b is slope of the line&amp;nbsp;and&amp;nbsp;e is error term. This equation can be used to predict the value of target variable based on given predictor&amp;nbsp;variable(s).&lt;/p&gt;&lt;p&gt;The difference between simple linear regression and multiple linear regression is that, multiple linear regression has (&amp;gt;1) independent variables, whereas simple linear regression has only 1 independent variable. &amp;nbsp;Now, the question is &ldquo;How do we obtain&amp;nbsp;best fit line?&rdquo;.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;How to&amp;nbsp;obtain best fit line (Value of a and b)?&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;This task can be easily accomplished by Least Square Method.&amp;nbsp;It is&amp;nbsp;the most common method used for fitting a regression line. It&amp;nbsp;calculates the best-fit line for the observed data by minimizing the sum of the squares of the vertical deviations from each data point to the line. Because the deviations are first squared, when added, there&amp;nbsp;is&amp;nbsp;no cancelling out between positive and negative values.&lt;/p&gt;&lt;figure class=&quot;image&quot;&gt;&lt;img src=&quot;https://www.analyticsvidhya.com/wp-content/uploads/2015/08/Least_Square.png&quot;&gt;&lt;/figure&gt;&lt;figure class=&quot;image&quot;&gt;&lt;img src=&quot;https://www.analyticsvidhya.com/wp-content/uploads/2015/08/reg_error.gif&quot;&gt;&lt;/figure&gt;&lt;p&gt;We can evaluate&amp;nbsp;the model performance using the metric&amp;nbsp;&lt;strong&gt;R-square&lt;/strong&gt;. To know more details about these metrics, you can read:&amp;nbsp;Model Performance metrics &lt;a href=&quot;https://www.analyticsvidhya.com/blog/2015/01/model-performance-metrics-classification/&quot;&gt;Part 1&lt;/a&gt;, &lt;a href=&quot;https://www.analyticsvidhya.com/blog/2015/01/model-perform-part-2/&quot;&gt;Part 2&lt;/a&gt;&amp;nbsp;.&lt;/p&gt;&lt;p&gt;Important Points:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;There must be &lt;strong&gt;linear relationship&lt;/strong&gt; between independent and dependent variables&lt;/li&gt;&lt;li&gt;Multiple regression suffers from &lt;strong&gt;multicollinearity, autocorrelation, heteroskedasticity&lt;/strong&gt;.&lt;/li&gt;&lt;li&gt;Linear Regression is very sensitive to &lt;strong&gt;Outliers&lt;/strong&gt;. It can terribly affect the regression line and&amp;nbsp;eventually the forecasted values.&lt;/li&gt;&lt;li&gt;Multicollinearity can increase the variance of the coefficient estimates and make the estimates very sensitive to minor changes in the model. The result is that the coefficient estimates are unstable&lt;/li&gt;&lt;li&gt;In case of multiple independent variables, we can go with &lt;strong&gt;forward selection&lt;/strong&gt;, &lt;strong&gt;backward elimination&lt;/strong&gt; and &lt;strong&gt;step wise approach&lt;/strong&gt; for selection of most significant independent variables.&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;', 1, '2022-02-09 11:14:33'),
(15, 112, 15, 'Conduction', '1647124538_conduction.JPG', '&lt;p&gt;Thermal conduction&amp;nbsp;is the transfer of&amp;nbsp;internal energy&amp;nbsp;by microscopic collisions of particles and movement of electrons within a body. The colliding particles, which include molecules, atoms and electrons, transfer disorganized microscopic kinetic and potential energy when joined, known as internal energy. Conduction takes place in most&amp;nbsp;phases: solid, liquid, and plasma.&lt;br&gt;Heat spontaneously flows from a hotter to a colder body. For example, heat is conducted from the hotplate of an electric stove to the bottom of a saucepan in contact with it. In the absence of an opposing external driving energy source, within a body or between bodies,&amp;nbsp;temperature&amp;nbsp;differences decay over time, and&amp;nbsp;thermal equilibrium&amp;nbsp;is approached, temperature becoming more uniform.&lt;br&gt;In conduction, the heat flow is within and through the body itself. In contrast, in heat transfer by&amp;nbsp;thermal radiation, the transfer is often between bodies, which may be separated spatially. Also possible is the transfer of heat by a combination of conduction and thermal radiation. In convection, the internal energy is carried between bodies by a moving material carrier. In solids, conduction is mediated by the combination of vibrations and collisions of molecules, of propagation and collisions of&amp;nbsp;phonons, and of diffusion and collisions of&amp;nbsp;free electrons. In gases and liquids, conduction is due to the collisions and&amp;nbsp;diffusion&amp;nbsp;of molecules during their random motion.&amp;nbsp;Photons&amp;nbsp;in this context do not collide with one another, and so heat transport by&amp;nbsp;electromagnetic radiation&amp;nbsp;is conceptually distinct from heat conduction by microscopic diffusion and collisions of material particles and phonons. But the distinction is often not easily observed unless the material is semi-transparent.&lt;br&gt;In the engineering sciences, heat transfer includes the processes of&amp;nbsp;thermal radiation,&amp;nbsp;convection, and sometimes mass transfer. Usually, more than one of these processes occurs in a given situation.&lt;/p&gt;', 1, '2022-03-12 22:35:38'),
(16, 112, 15, 'Convection', '1647124590_convection.jpg', '&lt;p&gt;Convection&amp;nbsp;is single or&amp;nbsp;multiphase&amp;nbsp;fluid flow&amp;nbsp;that occurs&amp;nbsp;spontaneously&amp;nbsp;due to the combined effects of&amp;nbsp;material property&amp;nbsp;heterogeneity&amp;nbsp;and&amp;nbsp;body forces&amp;nbsp;on a&amp;nbsp;fluid, most commonly&amp;nbsp;density&amp;nbsp;and&amp;nbsp;gravity&amp;nbsp;(see&amp;nbsp;buoyancy). When the cause of the convection is unspecified, convection due to the effects of&amp;nbsp;thermal expansion&amp;nbsp;and buoyancy can be assumed. Convection may also take place in soft&amp;nbsp;solids&amp;nbsp;or&amp;nbsp;mixtures&amp;nbsp;where particles can flow.&lt;/p&gt;&lt;p&gt;Convective flow may be&amp;nbsp;transient&amp;nbsp;(such as when a&amp;nbsp;multiphase&amp;nbsp;mixture&amp;nbsp;of&amp;nbsp;oil&amp;nbsp;and&amp;nbsp;water&amp;nbsp;separates) or&amp;nbsp;steady state&amp;nbsp;(see&amp;nbsp;Convection cell). The convection may be due to&amp;nbsp;gravitational,&amp;nbsp;electromagnetic&amp;nbsp;or&amp;nbsp;fictitious&amp;nbsp;body forces.&amp;nbsp;Heat transfer by natural convection&amp;nbsp;plays a role in the structure of&amp;nbsp;Earth&#039;s atmosphere, its&amp;nbsp;oceans, and its&amp;nbsp;mantle. Discrete convective cells in the atmosphere can be identified by&amp;nbsp;clouds, with stronger convection resulting in&amp;nbsp;thunderstorms. Natural convection also plays a role in&amp;nbsp;stellar physics. Convection is often categorised or described by the main effect causing the convective flow, e.g. Thermal convection.&lt;/p&gt;&lt;p&gt;Convection cannot take place in most solids because neither bulk current flows nor significant diffusion of matter can take place.&lt;/p&gt;', 1, '2022-03-12 22:36:30'),
(17, 112, 15, 'Radiation', '1647124639_Radiation.JPG', '&lt;p&gt;Heat transfer due to emission of electromagnetic waves is known as thermal radiation.&lt;/p&gt;&lt;p&gt;Heat transfer through radiation takes place in form of electromagnetic waves mainly in the infrared region. Radiation emitted by a body is a consequence of thermal agitation of its composing molecules. Radiation heat transfer can be described by reference to the&amp;nbsp;&#039;black body&#039;.&lt;/p&gt;&lt;p&gt;The black body is defined as a body that absorbs all radiation that falls on its surface. Actual black bodies don&#039;t exist in nature - though its characteristics are approximated by a hole in a box filled with highly absorptive material. The emission spectrum of such a black body was first fully described by Max Planck.&lt;br&gt;A black body is a hypothetical body that completely absorbs all wavelengths of thermal radiation incident on it. Such bodies do not reflect light, and therefore appear black if their temperatures are low enough so as not to be self-luminous. All black bodies heated to a given temperature emit thermal radiation.&lt;/p&gt;', 1, '2022-03-12 22:37:19'),
(18, 110, 14, 'Radial Velocity Method', '1647125313_radio.jpeg', '&lt;p&gt;The radial-velocity method for detecting exoplanets relies on the fact that a star does not remain completely stationary when it is orbited by a planet. The star moves, ever so slightly, in a small circle or ellipse, responding to the gravitational tug of its smaller companion. When viewed from a distance, these slight movements affect the star&#039;s normal light spectrum or color signature. The spectrum of a star that is moving towards the observer appears slightly shifted toward bluer (shorter) wavelengths. If the star is moving away, then its spectrum will be shifted toward redder (longer) wavelengths.&lt;/p&gt;', 0, '2022-03-12 22:48:33'),
(19, 110, 14, 'Direct Imaging', '1647125585_Di.jpeg', '&lt;p&gt;As the name would suggest, Direct Imaging consists of capturing images of exoplanets directly, which is possible by searching for the light reflected from a planet&rsquo;s atmosphere at infrared wavelengths. The reason for this is because, at infrared wavelengths, a star is only likely to be about 1 million times brighter than a planet reflecting light, rather than a billion times (which is typically the case at visual wavelengths).&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Advantages:&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;One of the most obvious advantages of Direct Imaging is that it is less prone to false positives. Whereas the Transit Method is prone to false positives in up to 40% of cases involving a single planet system (necessitating follow-up observations), planets detected using the Radial Velocity Method require confirmation (hence why it is usually paired with the Transit Method). In contrast, Direct Imaging allows astronomers to actually see the planets they are searching for.&lt;/p&gt;', 1, '2022-03-12 22:53:05'),
(20, 111, 18, 'Conductors', '1647132714_conductor.jpeg', '&lt;p&gt;In physics and electrical engineering, a conductor is an object or type of material that allows the flow of charge (electric current) in one or more directions. Materials made of metal are common electrical conductors. Electric current is generated by the flow of negatively charged electrons, positively charged holes, and positive or negative ions in some cases.&lt;/p&gt;&lt;p&gt;In order for current to flow within a closed electrical circuit, it is not necessary for one charged particle to travel from the component producing the current (the current source) to those consuming it (the loads). Instead, the charged particle simply needs to nudge its neighbor a finite amount, who will nudge its neighbor, and on and on until a particle is nudged into the consumer, thus powering it. Essentially what is occurring is a long chain of momentum transfer between mobile charge carriers; the Drude model of conduction describes this process more rigorously. This momentum transfer model makes metal an ideal choice for a conductor; metals, characteristically, possess a delocalized sea of electrons which gives the electrons enough mobility to collide and thus affect a momentum transfer.&lt;/p&gt;&lt;p&gt;As discussed above, electrons are the primary mover in metals; however, other devices such as the cationic electrolyte(s) of a battery, or the mobile protons of the proton conductor of a fuel cell rely on positive charge carriers. Insulators are non-conducting materials with few mobile charges that support only insignificant electric currents.&lt;/p&gt;', 1, '2022-03-13 00:51:54'),
(21, 111, 18, 'Insulator', '1647132775_insulator.jpeg', '&lt;p&gt;An electrical insulator is a material in which electric current does not flow freely. The atoms of the insulator have tightly bound electrons which cannot readily move. Other materials&mdash;semiconductors and conductors&mdash;conduct electric current more easily. The property that distinguishes an insulator is its resistivity; insulators have higher resistivity than semiconductors or conductors. The most common examples are non-metals.&lt;/p&gt;&lt;p&gt;A perfect insulator does not exist because even insulators contain small numbers of mobile charges (charge carriers) which can carry current. In addition, all insulators become electrically conductive when a sufficiently large voltage is applied that the electric field tears electrons away from the atoms. This is known as the breakdown voltage of an insulator. Some materials such as glass, paper and PTFE, which have high resistivity, are very good electrical insulators. A much larger class of materials, even though they may have lower bulk resistivity, are still good enough to prevent significant current from flowing at normally used voltages, and thus are employed as insulation for electrical wiring and cables. Examples include rubber-like polymers and most plastics which can be thermoset or thermoplastic in nature.&lt;/p&gt;&lt;p&gt;Insulators are used in electrical equipment to support and separate electrical conductors without allowing current through themselves. An insulating material used in bulk to wrap electrical cables or other equipment is called insulation. The term insulator is also used more specifically to refer to insulating supports used to attach electric power distribution or transmission lines to utility poles and transmission towers. They support the weight of the suspended wires without allowing the current to flow through the tower to ground.&lt;/p&gt;', 1, '2022-03-13 00:52:55'),
(22, 111, 18, 'Semiconductor', '1647132848_semi.jpeg', '&lt;p&gt;A semiconductor material has an electrical conductivity value falling between that of a conductor, such as metallic copper, and an insulator, such as glass. Its resistivity falls as its temperature rises; metals behave in the opposite way. Its conducting properties may be altered in useful ways by introducing impurities (&quot;doping&quot;) into the crystal structure. When two differently doped regions exist in the same crystal, a semiconductor junction is created. The behavior of charge carriers, which include electrons, ions, and electron holes, at these junctions is the basis of diodes, transistors, and most modern electronics. Some examples of semiconductors are silicon, germanium, gallium arsenide, and elements near the so-called &quot;metalloid staircase&quot; on the periodic table. After silicon, gallium arsenide is the second-most common semiconductor and is used in laser diodes, solar cells, microwave-frequency integrated circuits, and others. Silicon is a critical element for fabricating most electronic circuits.&lt;/p&gt;&lt;p&gt;Semiconductor devices can display a range of useful properties, such as passing current more easily in one direction than the other, showing variable resistance, and having sensitivity to light or heat. Because the electrical properties of a semiconductor material can be modified by doping and by the application of electrical fields or light, devices made from semiconductors can be used for amplification, switching, and energy conversion.&lt;/p&gt;&lt;p&gt;The conductivity of silicon is increased by adding a small amount (of the order of 1 in 108) of pentavalent (antimony, phosphorus, or arsenic) or trivalent (boron, gallium, indium) atoms. This process is known as doping, and the resulting semiconductors are known as doped or extrinsic semiconductors. Apart from doping, the conductivity of a semiconductor can be improved by increasing its temperature. This is contrary to the behavior of a metal, in which conductivity decreases with an increase in temperature.&lt;/p&gt;', 1, '2022-03-13 00:54:08'),
(23, 111, 18, 'Superconductor', '1647132901_super.jpeg', '&lt;p&gt;Superconductivity is a set of physical properties observed in certain materials where electrical resistance vanishes and magnetic flux fields are expelled from the material. Any material exhibiting these properties is a superconductor. Unlike an ordinary metallic conductor, whose resistance decreases gradually as its temperature is lowered even down to near absolute zero, a superconductor has a characteristic critical temperature below which the resistance drops abruptly to zero. An electric current through a loop of superconducting wire can persist indefinitely with no power source.&lt;/p&gt;&lt;p&gt;The superconductivity phenomenon was discovered in 1911 by Dutch physicist Heike Kamerlingh Onnes. Like ferromagnetism and atomic spectral lines, superconductivity is a phenomenon which can only be explained by quantum mechanics. It is characterized by the Meissner effect, the complete ejection of magnetic field lines from the interior of the superconductor during its transitions into the superconducting state. The occurrence of the Meissner effect indicates that superconductivity cannot be understood simply as the idealization of perfect conductivity in classical physics.&lt;/p&gt;', 1, '2022-03-13 00:55:01'),
(24, 106, 13, 'Gradient Descent', '1647136238_GD.png', '&lt;p&gt;&lt;strong&gt;Gradient Descent&lt;/strong&gt; is the most common optimization algorithm in &lt;i&gt;machine learning&lt;/i&gt; and &lt;i&gt;deep learning&lt;/i&gt;. It is a first-order optimization algorithm. This means it only takes into account the first derivative when performing the updates on the parameters. On each iteration, we update the parameters in the opposite direction of the gradient of the objective function &lt;i&gt;J(w)&lt;/i&gt; w.r.t the parameters where the gradient gives the direction of the steepest ascent. The size of the step we take on each iteration to reach the local minimum is determined by the learning rate &alpha;. Therefore, we follow the direction of the slope downhill until we reach a local minimum.&lt;/p&gt;&lt;p&gt;Let&rsquo;s first see how gradient descent works on logistic regression before going into the details of its variants. For the sake of simplicity, let&rsquo;s assume that the logistic regression model has only two parameters: weight &lt;i&gt;w&lt;/i&gt; and bias &lt;i&gt;b&lt;/i&gt;.&lt;/p&gt;&lt;p&gt;1. Initialize weight &lt;i&gt;w&lt;/i&gt; and bias &lt;i&gt;b&lt;/i&gt; to any random numbers.&lt;/p&gt;&lt;p&gt;2. Pick a value for the learning rate &alpha;. The learning rate determines how big the step would be on each iteration.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;If &alpha; is very small, it would take long time to converge and become computationally expensive.&lt;/li&gt;&lt;li&gt;If &alpha; is large, it may fail to converge and overshoot the minimum.&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;Therefore, plot the cost function against different values of &alpha; and pick the value of &alpha; that is right before the first value that didn&rsquo;t converge so that we would have a very fast learning algorithm that converges.&lt;/p&gt;&lt;p&gt;3. Make sure to scale the data if it&rsquo;s on a very different scales. If we don&rsquo;t scale the data, the level curves (contours) would be narrower and taller which means it would take longer time to converge&amp;nbsp;&lt;/p&gt;&lt;p&gt;4. On each iteration, take the partial derivative of the cost function &lt;i&gt;J(w)&lt;/i&gt; w.r.t each parameter (gradient).&lt;/p&gt;', 1, '2022-03-13 01:50:38'),
(25, 106, 13, 'Stochastic Gradient Descent', '1647136491_SGD.png', '&lt;p&gt;There are a few downsides of the gradient descent algorithm. We need to take a closer look at the amount of computation we make for each iteration of the algorithm.&lt;/p&gt;&lt;p&gt;Say we have 10,000 data points and 10 features. The sum of squared residuals consists of as many terms as there are data points, so 10000 terms in our case. We need to compute the derivative of this function with respect to each of the features, so in effect we will be doing 10000 * 10 = 100,000 computations per iteration. It is common to take 1000 iterations, in effect we have 100,000 * 1000 = 100000000 computations to complete the algorithm. That is pretty much an overhead and hence gradient descent is slow on huge data.&lt;/p&gt;&lt;p&gt;Stochastic gradient descent comes to our rescue !! &ldquo;Stochastic&rdquo;, in plain terms means &ldquo;random&rdquo;.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Where can we potentially induce randomness in our gradient descent algorithm??&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;Yes, you might have guessed it right !! It is while selecting data points at each step to calculate the derivatives. SGD randomly picks one data point from the whole data set at each iteration to reduce the computations enormously.&lt;/p&gt;&lt;p&gt;It is also common to sample a small number of data points instead of just one point at each step and that is called &ldquo;mini-batch&rdquo; gradient descent. Mini-batch tries to strike a balance between the goodness of gradient descent and speed of SGD.&lt;/p&gt;', 0, '2022-03-13 01:54:51'),
(26, 102, 11, 'K-means Clustering', '1647136849_Kmeans.png', '&lt;p&gt;&lt;strong&gt;Kmeans&lt;/strong&gt; algorithm is an iterative algorithm that tries to partition the dataset into &lt;i&gt;K&lt;/i&gt;pre-defined distinct non-overlapping subgroups (clusters) where each data point belongs to &lt;strong&gt;only one group&lt;/strong&gt;. It tries to make the intra-cluster data points as similar as possible while also keeping the clusters as different (far) as possible. It assigns data points to a cluster such that the sum of the squared distance between the data points and the cluster&rsquo;s centroid (arithmetic mean of all the data points that belong to that cluster) is at the minimum. The less variation we have within clusters, the more homogeneous (similar) the data points are within the same cluster.&lt;/p&gt;&lt;p&gt;The way kmeans algorithm works is as follows:&lt;/p&gt;&lt;ol&gt;&lt;li&gt;Specify number of clusters &lt;i&gt;K&lt;/i&gt;.&lt;/li&gt;&lt;li&gt;Initialize centroids by first shuffling the dataset and then randomly selecting &lt;i&gt;K &lt;/i&gt;data points for the centroids without replacement.&lt;/li&gt;&lt;li&gt;Keep iterating until there is no change to the centroids. i.e assignment of data points to clusters isn&rsquo;t changing.&lt;/li&gt;&lt;/ol&gt;&lt;ul&gt;&lt;li&gt;Compute the sum of the squared distance between data points and all centroids.&lt;/li&gt;&lt;li&gt;Assign each data point to the closest cluster (centroid).&lt;/li&gt;&lt;li&gt;Compute the centroids for the clusters by taking the average of the all data points that belong to each cluster.&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;The approach kmeans follows to solve the problem is called &lt;strong&gt;Expectation-Maximization&lt;/strong&gt;. The E-step is assigning the data points to the closest cluster. The M-step is computing the centroid of each cluster.&lt;/p&gt;', 1, '2022-03-13 02:00:49'),
(27, 116, 11, 'Hierarchical clustering', '1647137054_Hierarchical.png', '&lt;p&gt;As the name suggests, hierarchical clustering is a clustering algorithm. There are two different variations: Agglomerative &lt;i&gt;(from the part to the whole)&lt;/i&gt; and Divisive &lt;i&gt;(from the whole to the part) .&lt;/i&gt;&lt;/p&gt;&lt;p&gt;If we try to explain the agglomerative variation, first all the data is made into a cluster, that is, if there are N elements, N clusters are formed. Then, clusters that are close to each other in distance merge to form a new cluster. This situation continues until the system is stable. Divisive is the opposite of Agglomerative. At first all data is created in a single cluster. Then, this cluster is fragmented and clustering is performed.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;There are many ways to calculate distance in&lt;/strong&gt; agglomerative hierarchical clustering . They are also used to create dendrograms.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Single Linkage :&lt;/strong&gt; Calculates the closest distance between two clusters.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Complete Linkage:&lt;/strong&gt; Calculates the furthest distance between two clusters.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Average Linkage:&lt;/strong&gt; Calculates the average distance between two clusters.&lt;/p&gt;&lt;p&gt;Apart from these, there are &lt;strong&gt;ward&lt;/strong&gt; , &lt;strong&gt;weighted&lt;/strong&gt; , &lt;strong&gt;centroid&lt;/strong&gt; and &lt;strong&gt;median&lt;/strong&gt; methods. &lt;strong&gt;The method chosen affects the result.&lt;/strong&gt;&lt;/p&gt;', 1, '2022-03-13 02:04:14'),
(28, 105, 10, 'Logistic Regression', '1647137625_logistic.png', '&lt;p&gt;&lt;strong&gt;Logistic regression&lt;/strong&gt; is a process of modeling the probability of a discrete outcome given an input variable. The most common &lt;a href=&quot;https://www.sciencedirect.com/topics/computer-science/logistic-regression-model&quot;&gt;logistic regression models&lt;/a&gt; a binary outcome; something that can take two values such as true/false, yes/no, and so on. Multinomial logistic regression can model scenarios where there are more than two possible discrete outcomes. Logistic regression is a useful analysis method for classification problems, where you are trying to determine if a new sample fits best into a category. As aspects of cyber security are classification problems, such as attack detection, logistic regression is a useful &lt;a href=&quot;https://www.sciencedirect.com/topics/computer-science/analytics-technique&quot;&gt;analytic technique&lt;/a&gt;&lt;/p&gt;', 1, '2022-03-13 02:13:45'),
(36, 123, 9, 'SVM Classification', '1647340276_SVM_Classification.png', '&lt;p&gt;&lt;strong&gt;Definition:&amp;nbsp;&lt;/strong&gt;&lt;a href=&quot;https://analyticsindiamag.com/understanding-the-basics-of-svm-with-example-and-python-implementation/&quot;&gt;Support vector machine&lt;/a&gt;&amp;nbsp;is a representation of the training data as points in space separated into categories by a clear gap that is as wide as possible. New examples are then mapped into that same space and predicted to belong to a category based on which side of the gap they fall.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Advantages:&amp;nbsp;&lt;/strong&gt;Effective in high dimensional spaces and uses a subset of training points in the decision function so it is also memory efficient.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Disadvantages:&amp;nbsp;&lt;/strong&gt;The algorithm does not directly provide probability estimates, these are calculated using an expensive five-fold cross-validation.&lt;/p&gt;', 1, '2022-03-15 10:31:16');

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE `replies` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `body` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `replies`
--

INSERT INTO `replies` (`id`, `user_id`, `comment_id`, `body`, `created_at`, `updated_at`) VALUES
(74, 111, 53, 'Yes, it is possible.\n\nThe force produced by a magnetic field is proportional to the gradient of the magnetic field', '2022-03-13 14:28:18', NULL),
(75, 111, 55, 'Many metals become superconducting at low enough temperature; but then they are superconductors, and are no longer “ordinary conductors”. You can’t have it both ways.', '2022-03-13 14:32:48', NULL),
(77, 105, 56, 'No. it does not. Since it only depends on temperature and wavelength of the light.', '2022-03-14 21:20:43', NULL),
(78, 105, 51, 'Yes, The air which is cold is released by the air-conditioners. Now, this cold air is denser than the warm air, and, hence, it sinks. The warm air, being less dense, rises and is drawn in by the air-conditioner. As a result, convection current is set up and the room is cooled.', '2022-03-14 21:21:26', NULL),
(79, 120, 59, 'Thank you', '2022-03-14 21:58:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`id`, `name`, `description`) VALUES
(9, 'Classification', '<figure class=\"table\"><table><tbody><tr><td><strong>Classification is a task that requires the use of machine learning algorithms that learn how to assign a class label to examples from the problem domain. An easy-to-understand example is classifying emails as â€œ</strong><i><strong>spam</strong></i><strong>â€ or â€œ</strong><i><strong>not spam</strong></i><strong>.â€</strong></td></tr></tbody></table></figure>'),
(10, 'Regression', '<figure class=\"table\"><table><tbody><tr><td>Regression analysis is a form of predictive modeling technique which investigates the relationship between a dependent (target) and independent variable (s) (predictor). This technique is used for forecasting, time series modeling, and finding the <a href=\"https://www.analyticsvidhya.com/blog/2015/06/establish-causality-events/\">causal effect relationship</a> between the variables. For example, the relationship between rash driving and the number of road accidents by a driver is best studied through regression.</td></tr></tbody></table></figure>'),
(11, 'Clustering', '<figure class=\"table\"><table><tbody><tr><td><strong>Clustering is the task of dividing the population or data points into a number of groups such that data points in the same groups are more similar to other data points in the same group than those in other groups. In simple words, the aim is to segregate groups with similar traits and assign them into clusters.</strong></td></tr></tbody></table></figure>'),
(13, 'Optimization Methods', '<p><strong>Gradient descent</strong> (GD) is an iterative first-order optimization algorithm used to find a local minimum/maximum of a given function. This method is commonly used in <i>machine learning</i> (ML) and <i>deep learning</i>(DL) to minimize a cost/loss function (e.g. in linear regression). Due to its importance and ease of implementation, this algorithm is usually taught at the beginning of almost all machine learning courses.</p><p>However, its use is not limited to ML/DL only, it’s being widely used also in areas like:</p><ul><li>control engineering (robotics, chemical, etc.)</li><li>computer games</li><li>mechanical engineering</li></ul><p>That’s why today we will get a deep dive into the math, implementation, and behavior of the first-order gradient descent algorithm. We will navigate the custom (cost) function directly to find its minimum, so there will be no underlying data like in typical ML tutorials — we will be more flexible in terms of a function’s shape.</p><p>This method was proposed before the era of modern computers and there was an intensive development meantime which led to numerous improved versions of it but in this article, we’re going to use a basic/vanilla gradient descent implemented in Python.</p>'),
(14, 'Methods of Detecting Exoplanets', '<p>Any <a href=\"https://en.wikipedia.org/wiki/Planet\">planet</a> is an extremely faint light source compared to its parent <a href=\"https://en.wikipedia.org/wiki/Star\">star</a>. For example, a <a href=\"https://en.wikipedia.org/wiki/Star\">star</a> like the <a href=\"https://en.wikipedia.org/wiki/Sun\">Sun</a> is about a billion times as bright as the reflected light from any of the planets orbiting it. In addition to the intrinsic difficulty of detecting such a faint light source, the light from the parent star causes a glare that washes it out. For those reasons, very few of the <a href=\"https://en.wikipedia.org/wiki/Exoplanet\">exoplanets</a> reported as of April&nbsp;2014 have been observed directly, with even fewer being resolved from their host star.</p><p>Instead, <a href=\"https://en.wikipedia.org/wiki/Astronomer\">astronomers</a> have generally had to resort to indirect methods to detect extrasolar planets. As of 2016, several different indirect methods have yielded success.</p>'),
(15, 'Heat transfer Mechanisms', '<p><strong>Heat transfer mechanisms</strong> are the ways by which thermal energy can be transferred between objects, and they all rely on the basic principle that kinetic energy or heat wants to be at equilibrium or at <i>equal energy states</i>. There are three different ways for <a href=\"https://energyeducation.ca/encyclopedia/Heat_transfer\">heat transfer</a> to occur: <a href=\"https://energyeducation.ca/encyclopedia/Conduction\">conduction</a>, <a href=\"https://energyeducation.ca/encyclopedia/Convection\">convection</a>, and <a href=\"https://energyeducation.ca/encyclopedia/Radiant_heat\">radiant heat</a> (often referred to as <a href=\"https://energyeducation.ca/encyclopedia/Radiation\">radiation</a>, but that\'s a more general term that includes many other phenomena).<a href=\"https://energyeducation.ca/encyclopedia/Heat_transfer_mechanisms#cite_note-2\">[2]</a> There is a related phenomenon that transfers <a href=\"https://energyeducation.ca/encyclopedia/Latent_heat\">latent heat</a> called <a href=\"https://energyeducation.ca/encyclopedia/Evapotranspiration\">evapotranspiration</a>.</p>'),
(18, 'Static Electricity', '<p>Static electricity is <strong>an imbalance of electric charges within or on the surface of a material or between materials</strong>. The charge remains until it is able to move away by means of an electric current or electrical discharge.</p>'),
(19, 'Power Transmission Lines', '<p>Power transmission lines are <strong>used to connect power stations and substations, and for connections between substations, in order to efficiently transmit large amounts of electricity at high voltage without loss</strong>, and therefore play a crucial role in providing electricity.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `admin` tinyint(4) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `admin`, `username`, `email`, `password`, `created_at`) VALUES
(102, 1, 'stummala', 'srilekha.tummala@st.de', '$2y$10$QSeW.76GoHwpbCHKnWGHee.QpVbeGBAasQuNUfk4CKJTs.k.s5kYK', '2022-02-07 12:47:44'),
(105, 1, 'fahmad', 'fraz.ahmad@st.ovgu.de', '$2y$10$U4WvByuE6fAh9xNTRy/snusn5/lTwHdfXBmUmoyyqnFrSHycGUCgi', '2022-02-07 12:49:16'),
(106, 0, 'Anshul', '244anshul@gmail.com', '$2y$10$lX0uiM3jzmuilT2LGuDTte6.ckhgkZSrPx0qX4/O84sGyEHPcjEEO', '2022-02-07 19:05:40'),
(107, 1, 'mhossain', 'maruf.hossain@st.ovgu.de', '$2y$10$sWZ0AyZ9fClkJqLeehO5PuoQJf93uQ2q9Jn5D4EKpQKLSoYq8aF4G', '2022-02-08 14:50:46'),
(110, 0, 'vkudaravalli', 'vnckudaravalli@gmail.com', '$2y$10$jn7cz0B4CL4/T94j.PUeb.EVRTMEuLxQiqzblzYnAYj1.8RLDgw6q', '2022-03-12 22:09:42'),
(111, 0, 'vakula', 'anjiakula@gmail.com', '$2y$10$/u1HAab8MUM0xM7cJ5HPYeb/Zif4Pgqghx4AourmcDD2gDkafIxuO', '2022-03-12 22:12:00'),
(112, 0, 'sjulian', 'simsonjulianrodrigues@gmail.com', '$2y$10$ww3PPdjNZbyZp5I3EukGuexvrp55BWz9I6BbWxGS.EQV6N1O4pZpe', '2022-03-12 22:14:42'),
(113, 0, 'kushagra', 'kushagra.kumar@st.ovgu.de', '$2y$10$ZQH0LwYXC3RqT9p/E9.gOOXXjHLq21zDI7jb7cw6kWugQNl/4/oo.', '2022-03-14 14:35:47'),
(114, 0, 'skatti', 'surabhi.katti@st.ovgu.de', '$2y$10$PXZHLf6T39EkcE063t8T..30xKmiYLBPMYYjssTXPp/91Bt42k2h2', '2022-03-14 14:36:48'),
(115, 0, 'sthutiS', 'sthutiS@gmail.com', '$2y$10$E2Bs1mFrNFlNzSCYf5yy3OoYCBokt74Py8hoK88bD1Qwff54rdYIW', '2022-03-14 14:37:40'),
(116, 0, 'Ranjitha', 'ranjithath244@gmail.com', '$2y$10$fvbiHoZGH2M60Svw/Ns5M.nLWMM2MJ9BMwe6i8A5TwphaOtAv3v.6', '2022-03-14 14:38:23'),
(117, 0, 'anirudha', 'anirudh@gmail.com', '$2y$10$vGBLAUixlKDqpdTEIS9BA.ALQBURyQ9QoeaIwx75Exg0AJ2KspWCC', '2022-03-14 14:39:00'),
(118, 0, 'david', 'David483@gmail.com', '$2y$10$Kpx6/mxKKhxmWPjHF/wMAOYbjBAv4i4Fim8KVNiNHS6vl8xAiGa1K', '2022-03-14 14:39:34'),
(123, 0, 'stummala@1', 'tummalasrilekha@gmail.com', '$2y$10$UB9uOXXrZtt0inIDUnyXFOpHXaqCrVIWzh39Yaph7zIZOb5fli0Da', '2022-03-15 10:30:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `discussion`
--
ALTER TABLE `discussion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user` (`user`),
  ADD KEY `r_id` (`r_id`);

--
-- Indexes for table `disc_reply`
--
ALTER TABLE `disc_reply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `postid` (`postid`,`userid`) USING BTREE,
  ADD KEY `userid` (`userid`),
  ADD KEY `postid_2` (`postid`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `topic_id` (`topic_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `comment_id` (`comment_id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `users_username_uindex` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `discussion`
--
ALTER TABLE `discussion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `disc_reply`
--
ALTER TABLE `disc_reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `replies`
--
ALTER TABLE `replies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
