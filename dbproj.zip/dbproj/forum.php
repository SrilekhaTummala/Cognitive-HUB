<?php 
      include("path.php");
      include(ROOT_PATH . "/app/controllers/forum.php"); 
      error_reporting(0);
      $user = $_SESSION['username'];    

?>
	
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
          integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr"
          crossorigin="anonymous">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Candal|Lora"
          rel="stylesheet">

    <!-- Custom Styling -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin.css">


    <title>Cognitive HUB Forum</title>
    
</head>

<body>
<?php include(ROOT_PATH . "/app/includes/header.php"); ?>
<div class="admin-wrapper">
      <div class="admin-content">
            <div class="content">
            <h2 style="text-align:center; color:#2980B9;">Cognitive HUB FORUM</h2>
                  <?php if(isset($_SESSION['id'])){
                  echo "<form method='POST' action='".setComments($conn)."'>
                              <input type='hidden' name='user' value='$user' class='text-input'>
                              <textarea name='post'  placeholder='Enter your question here...' class='text-input'></textarea><br>
                              <button type='submit' name='forum_query' class='btn btn-sm' style='margin-bottom:10px; background-color:#234a57'>Send</button>
                        </form>";

                        
                  getComments($conn);
                  }
                  else{?>
                  <h4 style="text-align:center;">Please login to post a question</h4>
                  <?php getComments($conn);}
                  //getReplies($conn);
                  ?>
            </div>
      </div>
</div>


<script 
      src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"></script>

<script 
      src=https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js></script>

<script 
      src=https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css></script>

<script
	src=https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js></script>

</body>
</html>

