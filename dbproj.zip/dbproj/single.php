<?php
	include("path.php");
	include(ROOT_PATH . '/app/controllers/posts.php');
	include(ROOT_PATH . '/comments/functions.php');
	
	usersOnly();
	
	global $username;
	$post = array();
	$UID = $_SESSION['id'];
	$PID = $_GET['id'];
	
	if (isset($_GET['id'])) {
		$post = selectOne('posts', ['id' => $_GET['id']]);
		if(!empty($post)){
			$user = selectOne('users', ['id' => $post['user_id']]);
		}
	}
	$topics = selectAll('topics');
	$posts = selectAll('posts', ['published' => 1]);
	
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

	<!-- Bootstrap -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	
	
	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Candal|Lora" rel="stylesheet">

	<!-- Custom Styling -->
	<link rel="stylesheet" href="assets/css/style.css">

	<title> <?php echo html_entity_decode($post['title']); ?> </title>
</head>

<body>

<?php include(ROOT_PATH . "/app/includes/header.php"); ?>
<div class="page-wrapper">
	<!-- Content -->
	<div class="content clearfix">

		<div class="main-content-wrapper">
			<div class="main-content single">
				<h1 class="post-title">
					<?php echo $post['title']; ?>
				</h1>
				<div class="blog_info_left_grid">
					<a href="#">
						<img src="assets/images/<?php echo $post['image']; ?>" class="img-fluid" style = "width: 95%; height: 270px; margin: 20px auto;	border-radius: 5px;	background: white; position: relative;" alt="assets/images/CHUB.jpg">
					</a>
					<ul>
					
						<a href="#" style = "font-style: italic; font-size: 0.8em;">
							<i class="fa fa-calendar" aria-hidden="true"></i> <?php echo date('F j, Y', strtotime($post['created_at'])); ?></a> &nbsp;
						<a href="#" style = "font-style: italic; font-size: 0.8em;">
							<i class="fa fa-user"></i> <?php echo $user['username']; ?></a>
						
					</ul>
				</div>
				<?php echo html_entity_decode($post['body']);?>
				
				<form class="like clearfix" action="" method="post" id="like_form" style="margin: 10px">
					<button class="btn btn-primary btn-sm pull-right" id="submit_like" style="margin: 5px 0px; font-size: 0.8em;">Like</button>
					<h4><span id="likes_count"><?php echo $totalLikes ?></span> Likes</h4>
				</form>
				
				
				<div class="comments-section" style="margin-top: 10px;	border: 1px solid #ccc;">
					<form class="clearfix" action="" method="post" id="comment_form" style="margin: 10px">
						<textarea style="display: block; float:right;" name="comment_text" id="comment_text" class="form-control" cols="30" rows="3"></textarea>
						<button class="btn btn-primary btn-sm pull-right" id="submit_comment" style="margin: 5px 0px; font-size: 0.8em;">Comment</button>
					</form>
				
					<!-- Display total number of comments on this post  -->
					<h4><span id="comments_count"><?php echo count($comments) ?></span> Comment(s)</h4>
					<hr>
					<!-- comments wrapper -->
					<div id="comments-wrapper">
						<?php if (isset($comments)): ?>
							<!-- Display comments -->
							<?php foreach ($comments as $comment): ?>
								
								<!-- comment -->
								<div class="comment clearfix" style="margin-bottom: 10px;">
									<div class="comment-details" style="width: 91.5%; float: left; padding: 10px">
										<span class="comment-name" style="font-weight: bold;"><?php echo getUsernameById($comment['user_id']) ?></span>
										<span class="comment-date" style="font-style: italic; font-size: 0.8em;"><?php echo date("F j, Y ", strtotime($comment["created_at"])); ?></span>
										<p><?php echo $comment['body']; ?></p>
										<a class="reply-btn" style="font-size: 0.8em;" href="" data-id="<?php echo $comment['id']; ?>">Reply</a>
									</div>
									<!-- reply form -->
									<form action="" class="reply_form clearfix" style="margin-left: 40px; margin-right:10px; display: none;" id="comment_reply_form_<?php echo $comment['id'] ?>" data-id="<?php echo $comment['id']; ?>">
										<textarea class="form-control" name="reply_text" id="reply_text" cols="30" rows="2"></textarea>
										<button class="btn btn-primary btn-xs pull-right submit-reply" style="font-size: 0.8em; margin: 5px 0px;">Submit reply</button>
									</form>

									<!-- GET ALL REPLIES -->
									<?php $replies = getRepliesByCommentId($comment['id']) ?>
									<div class="replies_wrapper_<?php echo $comment['id']; ?>">
										<?php if (isset($replies)): ?>
											<?php foreach ($replies as $reply): ?>
												<!-- reply -->
												<div class="comment reply clearfix" style="margin-left: 30px;">
													<div class="comment-details" style="width: 91.5%; float: left;">
														<span class="comment-name" style="font-weight: bold;"><?php echo getUsernameById($reply['user_id']) ?></span>
														<span class="comment-date" style="font-style: italic; font-size: 0.8em;"><?php echo date("F j, Y ", strtotime($reply["created_at"])); ?></span>
														<p><?php echo $reply['body']; ?></p>
													</div>
												</div>
											<?php endforeach ?>
										<?php endif ?>
									</div>
								</div>
								<!-- // comment -->
							<?php endforeach ?>
						<?php else: ?>
							<h2>Be the first to comment on this post</h2>
						<?php endif ?>
					</div><!-- comments wrapper -->
				</div><!-- // all comments -->
				
			</div>
		</div>

		<div class="sidebar single">
			<div class="section topics">
				<h2 class="section-title">Topics</h2>
				<ul>
					<?php foreach ($topics as $topic): ?>
						<li>
							<a href="<?php echo BASE_URL . '/index.php?t_id=' . $topic['id'] . '&name=' . $topic['name'] ?>">
								<?php echo $topic['name']; ?></a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>

	</div>
	<!-- //Content -->

</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/12.3.1/classic/ckeditor.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="assets/js/scripts.js"></script>
<script src="comments/scripts.js"></script>

<?php include(ROOT_PATH . "/app/includes/footer.php"); ?>
</body>

</html>