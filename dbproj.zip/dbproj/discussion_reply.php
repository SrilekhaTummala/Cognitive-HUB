<?php
    include ("path.php");
    include (ROOT_PATH . "/app/controllers/forum.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
          integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr"
          crossorigin="anonymous">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Candal|Lora"
          rel="stylesheet">

    <!-- Custom Styling -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin.css">


    <title>Edit forum query</title>
    
</head>

<body>
<?php include(ROOT_PATH . "/app/includes/header.php"); ?>
<div class="admin-wrapper">
      <div class="admin-content">
            <div class="content">
                  <?php

                    $cid = $_POST['cid'];
                    $user = $_SESSION['username'];
                    echo 
                    "<form method='POST' action='".setReply($conn)."'>
                        <input type='hidden' name='cid' value='$cid' class='text-input'>
                        <input type='hidden' name='user' value='$user' class='text-input'>
                        <textarea name='body'  placeholder='Reply here...' class='text-input'></textarea><br>
                        <button type='submit' name='forum_reply' class='btn btn-sm' style='margin-bottom:10px; background-color:#234a57'>Reply</button>
                        <button type='submit' name='forum_reply_cancel' class='btn btn-sm' style='margin-bottom:10px; background-color:#234a57'>Cancel</button>
                    </form>";
                  
                  ?>
            </div>
      </div>
</div>

<script 
    src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script 
    type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<!-- Ckeditor -->
<script 
    src="https://cdn.ckeditor.com/ckeditor5/12.2.0/classic/ckeditor.js"></script>

</body>
</html>