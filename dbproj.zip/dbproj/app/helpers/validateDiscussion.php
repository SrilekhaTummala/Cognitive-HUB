<?php
	
	function validateDiscussion($disc) {
		$errors = array();
		
		if (empty($disc['user'])) {
			array_push($errors, 'Name is required');
		}
		
		/*if ($disc['user'] != $_SESSION['username']) {
			array_push($errors, 'Please use your username');
		}*/
		
		if (empty($disc['post'])) {
			array_push($errors, 'Please post a query if you have one!');
		}
		
		return $errors;
	}
