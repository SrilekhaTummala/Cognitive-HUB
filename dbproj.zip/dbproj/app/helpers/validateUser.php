<?php

	function validatePasschnage($user){
		$errors = array();

		$existingUsername = selectOne('users', ['username' => $user['username']]);
		$existingUser = selectOne('users', ['username' => $user['username'] , 'email' => $user['email']]);

		if (empty($user['username'])) {
			array_push($errors, 'Username is required');
		} else{
			if (!$existingUsername) {
				array_push($errors, 'Sorry username does not exist. Please register');
			}
		}
		
		if (empty($user['email'])) {
			array_push($errors, 'Email is required');
		} else{
			if (!$existingUser) {
				array_push($errors, 'Username and Email are not matching. Please provide valid details');
			}
		}
		
		if (empty($user['password'])) {
			array_push($errors, 'Password is required');
		}
		
		if ($user['passwordConf'] !== $user['password']) {
			array_push($errors, 'Password do not match');
		}

		return $errors;
	}
	
	function validateUser($user) {
		$errors = array();

		$existingUsername = selectOne('users', ['username' => $user['username']]);
		
		if (empty($user['username'])) {
			array_push($errors, 'Username is required');
		} elseif($existingUsername){
			array_push($errors, 'Username already exists. Please provide another username');
		}
		
		if (empty($user['email'])) {
			array_push($errors, 'Email is required');
		}
		
		if (empty($user['password'])) {
			array_push($errors, 'Password is required');
		}
		
		if ($user['passwordConf'] !== $user['password']) {
			array_push($errors, 'Password do not match');
		}
		
		// $existingUser = selectOne('users', ['email' => $user['email']]);
		// if ($existingUser) {
		//     array_push($errors, 'Email already exists');
		// }
		
		$existingUser = selectOne('users', ['email' => $user['email']]);
		if ($existingUser) {
			if (isset($user['update-user']) && $existingUser['id'] != $user['id']) {
				array_push($errors, 'Email already exists');
			}
			
			if (isset($user['modify-user']) && $existingUser['id'] != $user['id']) {
				array_push($errors, 'Email already exists');
			}
		}
		
		return $errors;
	}
	
	
	function validateLogin($user) {
		$errors = array();
		
		if (empty($user['username'])) {
			array_push($errors, 'Username is required');
		}
		
		if (empty($user['password'])) {
			array_push($errors, 'Password is required');
		}
		
		return $errors;
	}