<?php

	if(isset($_SERVER['HTTP_REFERER'])){
		$return_to = $_SERVER['HTTP_REFERER'];
	} else{
		$return_to = " /single.php";
	}
