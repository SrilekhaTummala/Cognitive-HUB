<?php
	include(ROOT_PATH . "/app/database/db.php");
	
	$table = 'comment';
	global $conn;
	
	$forum = selectAll($table);
	
	$errors = array();
	$id = '';
	$user_id = '';
	$msg = '';
	$post_id = '';
	
	if(isset($_POST[]))
	{
		$id = mysqli_real_escape_string($conn , $_POST['comment']);
		$reply_msg = mysqli_real_escape_string($conn , $_POST['reply_msg']);
		$user_id = $_SESSION['id'];
		
		$query = "INSERT into replies(user_id, comment_id, body) VALUES ('$user_id','$id','$reply_msg')";
		$query_run = mysqli_query($conn, $query);
		
		if($query_run){
			echo "Comment Replied";
		}
		else{
			echo "Something went wrong";
		}
	}
	
	
	if(isset($_POST['comment_load_data']))
	{
		$comments_query = "SELECT * FROM comment";
		$comments_query_run = mysqli_query($conn, $comments_query);
		$array_res = [];
		
		if(mysqli_num_rows($comments_query_run) > 0)
		{
			foreach ($comments_query_run as $row)
			{
				$user_id = $row['user_id'];
				$user_query = "SELECT * FROM users WHERE id = '$user_id' LIMIT 1";
				$user_query_run = mysqli_query($conn, $user_query);
				$user_result = mysqli_fetch_array($user_query_run);
				
				$array_res[] = ['cmt' => $row, 'user' => $user_result];
				
			}
			header('Content-type: application/json');
			echo json_encode($array_res);
		}
		else
		{
			echo "";
		}
	}
	
	
	if(isset($_POST['add_comment'])){
		$msg = $_POST['msg'];
		$user_id = $_SESSION['id'];
		
		$comment_add_query = "INSERT into comment (user_id, body)  VALUES ('$user_id','$msg')";
		$comment_add_query_run = mysqli_query($conn, $comment_add_query);
		
		if($comment_add_query_run){
			echo "Comment added successfully";
		}
		else{
			echo "OOPS! Something went wrong...comment cannot be added";
		}
	
	}
