<?php
	
	include(ROOT_PATH . "/app/database/db.php");
	include(ROOT_PATH . "/app/helpers/middleware.php");
	include(ROOT_PATH . "/app/helpers/validateDiscussion.php");

	global $conn;
	
	$table = 'discussion';
	
	$forum = selectAll($table);
	
	$errors = array();
	$id = '';
	$parent_comment = '';
	$user = '';
	$post = '';
	
	

	function setComments($conn){
		if (isset($_POST['forum_query'])) {
			//$errors = validateDiscussion($_POST);
			//if (count($errors) === 0) {
				unset($_POST['forum_query']);
				
				$forum_id = create('discussion', $_POST);
				$forum_user = selectOne('discussion', ['id' => $forum_id]);
	
			
		}
	}
	
	function getComments($conn) {
		
		$sql = "SELECT * FROM discussion ORDER BY date DESC";
		$result = mysqli_query($conn, $sql);
		$fetch_row = $result->fetch_all(MYSQLI_ASSOC);
		
		foreach($fetch_row as $row){
			$cid = $row['id'];
			$rid = $row['r_id'];
			echo "<div class='comment-box' style='position:relative; background-color:#fff; padding:20px; margin-bottom:4px; border-radius: 4px;'>
				<p style='color:#282828;'>";
				echo "<p style='font-weight: bold; margin-bottom:0px;'>".$row['user']."</p>";
				echo "<p style='font-style: italic; font-size: 0.8em; margin-top:0px; margin-bottom:10px'>".$row['date']."<br></p>";
				echo "<p style = 'position:relative; left:10px; margin-top:0px'>" .nl2br($row['post'])."";
			echo "</p>";
			if(isset($_SESSION['id'])){
				if($_SESSION['username'] == $row['user']){
					
					echo "<form class='edit-form' style='position:absolute; top:5px; right:5px;' method='POST' action='discussion.php'>
						<input type='hidden' name='id' value='".$row['id']."'>
						<input type='hidden' name='user' value='".$row['user']."'>
						<input type='hidden' name='post' value='".$row['post']."'>
						<input type='hidden' name='date' value='".$row['date']."'>
						<button type='submit' name='edit_btn' style='color:white; background-color:#234a57; border-radius:4px;'>Edit</button>
					</form>
					<form class='del_form' style='position:absolute; top:5px; right:49px;' method='POST' action='".delComments($conn)."'>
						<input type='hidden' name='id' value='".$row['id']."'>
						<button type='submit' name='del_btn' style='color:white; background-color:#CE0808; border-radius:4px;'>Delete</button>
					</form>";
				}
				if($_SESSION['admin']){
					
					echo"
						<form class='edit_form' style='position:absolute; top:5px; right:110px;' method='POST' action='discussion_reply.php'>
							<input type='hidden' name='cid' value='".$row['id']."'>
							<input type='hidden' name='user' value='".$row['user']."'>
							<button type='submit' name='reply_btn' style='color:black;'>Reply</button>
						</form>";
					}
			}

			if($rid){
			$sql1 = "SELECT * FROM disc_reply WHERE id='$rid' AND cid='$cid' LIMIT 1";
			$disc_res = mysqli_query($conn,$sql1);
			$disc_row = $disc_res->fetch_all(MYSQLI_ASSOC);
			
			foreach ($disc_row as $reply_disc){
				echo "<div class='comment-box' style='position:relative; background-color:#fff; padding:20px; margin-bottom:4px; border-radius: 4px;'>
				<p style='color:#282828;'>";
					echo "<p style='position:relative; left:30px; font-weight: bold; margin-bottom:0px;'>".$reply_disc['user']."</p>";
					echo "<p style='position:relative; left:30px; font-style: italic; font-size: 0.8em; margin-top:0px; margin-bottom:10px'>".$reply_disc['created_at']."<br></p>";
					echo "<p style = 'position:relative; left:50px; margin-top:0px'>" .nl2br($reply_disc['body'])."";
				echo "</p>";
				if(isset($_SESSION['id'])){
					
					if($_SESSION['username'] == $reply_disc['user']){
						echo "<form class='edit-form' style='position:absolute; top:5px; right:5px;' method='POST' action='discussion.php'>
							<input type='hidden' name='id' value='".$row['id']."'>
							<input type='hidden' name='user' value='".$row['user']."'>
							<input type='hidden' name='post' value='".$row['post']."'>
							<input type='hidden' name='date' value='".$row['date']."'>
							<button type='submit' name='edit_btn' style='color:white; background-color:#234a57; border-radius:4px;'>Edit</button>
						</form>
						<form class='del_form' style='position:absolute; top:5px; right:49px;' method='POST' action='".delComments($conn)."'>
							<input type='hidden' name='id' value='".$row['id']."'>
							<button type='submit' name='del_btn' style='color:white; background-color:#CE0808; border-radius:4px;'>Delete</button>
						</form>";
					}
				}
				echo "</div>";
				}
			}
			echo "</div>";
		}
			
	}
	



	function editComments($conn){
		if (isset($_POST['edit_forum_query'])) {
			$id = $_POST['id'];
			$user = $_POST['user'];
			$post = $_POST['post'];
			$date = $_POST['date'];

			$sql = "UPDATE discussion SET post='$post' WHERE id='$id'";
			echo "updated query";
			$result = mysqli_query($conn, $sql);
			header("Location: forum.php");
		} 
		elseif(isset($_POST['cancel_edit_forum_query'])){
			header("Location: forum.php");
		}
	}

	function delComments($conn){
		if (isset($_POST['del_btn'])) {
			$id = $_POST['id'];

			$sql = "DELETE FROM discussion WHERE id='$id'";
			$result = mysqli_query($conn, $sql);
			header("Location: forum.php");
		}
	}


	function setReply($conn){
		if (isset($_POST['forum_reply'])) {
			unset($_POST['forum_reply']);
						
			$rid = create('disc_reply', $_POST);
			$f_reply = selectOne('disc_reply', ['id' => $rid]);	
			
			$sql = "UPDATE discussion SET r_id ='$rid' WHERE id = '$f_reply[cid]'";
			$result = mysqli_query($conn, $sql);
			
			header("Location: forum.php");
		}
		elseif(isset($_POST['forum_reply_cancel'])){
			header("Location: forum.php");
		}
	}

	function get_all($conn, $rid){
		global $conn;
		$sql = "SELECT * FROM discussion ORDER BY date DESC";
		$result = mysqli_query($conn, $sql);
		$row = mysqli_fetch_assoc($result);
		$length_sql = "SELECT COUNT(*) FROM discussion";
		$length_res = mysqli_query($conn, $length_sql);
		$length = mysqli_num_rows($length_res);
				
		$level[0] = $rid;
        for ($i=0; $i<$length; $i++ )
        {
            $j = $i+1;
            $search = "SELECT * FROM discussion where r_id='$level[$i]'";
            $result = mysqli_query($conn, $search);
            $row = mysqli_fetch_array($result);
            $level[$j] = $row['id'];
			
        }
		get_reply($conn, $level);
	}


	function get_reply($conn, array $pos){
		$sql = "SELECT * FROM disc_reply WHERE id=$pos[0] AND cid=$pos[1] ";
		$disc_res = mysqli_query($conn,$sql);
		$disc_row = mysqli_fetch_assoc($disc_res);
		while($disc_row){
			echo "<div class='reply-box' style='position:relative; background-color:#fff; padding:20px; margin-bottom:4px; border-radius: 4px;'>
			<p style='color:#282828;'>";
				echo "<p style='font-weight: bold; margin-bottom:0px;'>".$disc_row['user']."</p>";
				echo "<p style='font-style: italic; font-size: 0.8em; margin-top:0px; margin-bottom:10px'>".$disc_row['created_at']."<br></p>";
				echo "<p style = 'position:relative; left:20px; margin-top:0px'>" .nl2br($disc_row['body'])."";
		echo "</p></div>";
		}
		
	}
	    
// 		$sql = "SELECT * FROM table WHERE cid =  " . ($parent_id ? 'IS NULL' : "= $parent_id");
//     $result = mysqli_query($link, $sql);

//     if ($result && mysqli_num_rows($result) > 0) {
//         while($row = mysqli_fetch_assoc($result)) {
//             if ($row['parent_id']) {
//                 $levels[] = $row['parent_id'];
//             }
//             get_all($levels, $row['id']);
//         }
//     }
// }

// $levels = [];
// get_all($levels);
//	}
